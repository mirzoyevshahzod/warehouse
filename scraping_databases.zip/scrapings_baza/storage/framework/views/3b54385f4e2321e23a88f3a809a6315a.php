<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <svg class="menu-icon" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
            </svg>
            Dashboard
        </div>
    </div>

    <ul class="sidebar-menu">

        <li>
            <a href="<?php echo e(route('belarusBenyakoni')); ?>"
               class="<?php echo e(request()->routeIs('belarusBenyakoni') ? 'active' : ''); ?>">

                Benyakoni
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('belarusBrest')); ?>"
               class="<?php echo e(request()->routeIs('belarusBrest') ? 'active' : ''); ?>">

                Brest
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('belarusGigorovschina')); ?>"
               class="<?php echo e(request()->routeIs('belarusGigorovschina') ? 'active' : ''); ?>">

                Gigorovschina
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('belarusKeminnii')); ?>"
               class="<?php echo e(request()->routeIs('belarusKeminnii') ? 'active' : ''); ?>">

                Keminnii-log
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('belarusKozlovichi')); ?>"
               class="<?php echo e(request()->routeIs('belarusKozlovichi') ? 'active' : ''); ?>">

                Kozlovichi
            </a>
        </li>

        <li>
            <a href="/">
                Bosh Sahifaga Qaytish
            </a>
        </li>

    </ul>
</aside>
<?php /**PATH /home/sanjarbek/project/scrapings_baza/resources/views/components/belarus/sidebar.blade.php ENDPATH**/ ?>